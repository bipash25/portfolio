import React, { useState, useEffect } from "react";
import { Container, Row } from "react-bootstrap";
// import Button from "react-bootstrap/Button";
import Particle from "../Particle";
// import { AiOutlineDownload } from "react-icons/ai";
// import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/esm/Page/AnnotationLayer.css";
// pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

function ResumeNew() {
  const [width, setWidth] = useState(1200);

  useEffect(() => {
    setWidth(window.innerWidth);
  }, []);

  return (
    <div>
      <Container fluid className="resume-section">
        <Particle />
        <Row style={{ justifyContent: "center", position: "relative" }}>
          <h1 className="heading-name">
            <strong className="main-name"> Not Prepared For It Yet..</strong>
          </h1>
        </Row>

        <Row style={{ justifyContent: "center", position: "relative" }}>
          <h1 className="heading-name">
            <strong className="main-name"> Coming Soon...</strong>
          </h1>
        </Row>
      </Container>
    </div>
  );
}

export default ResumeNew;
